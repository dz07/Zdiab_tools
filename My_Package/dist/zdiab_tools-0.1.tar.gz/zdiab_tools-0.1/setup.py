from setuptools import setup

setup(name='zdiab_tools',
      version='0.1',
      description='Rasa preprocessing package',
      packages=['zdiab_tools'],
      author = 'zohair diab',
      author_email = 'zohairdiab07@gmail.com',
      zip_safe=False)
